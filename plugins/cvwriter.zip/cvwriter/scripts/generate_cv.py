#!/usr/bin/env python3
from __future__ import annotations

import runpy
from pathlib import Path


PREPARE_SCRIPT = Path(__file__).resolve().with_name("prepare_cv_payload.py")


if __name__ == "__main__":
    runpy.run_path(str(PREPARE_SCRIPT), run_name="__main__")
